# floura_mobile_app
this is the curently developed app for the final year and the above mentioned code is the main actvity code and weather activty code.
this code is for identifying the disease ,weather language prediction.
